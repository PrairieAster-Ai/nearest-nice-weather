"use client"

import { GET } from "../api/health-check"

export default function SyntheticV0PageForDeployment() {
  return <GET />
}